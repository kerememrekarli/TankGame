final class A_Const 
{
  // size of the world
  static final int WORLD_WIDTH      = 950;
  static final int WORLD_HEIGHT     = 700;

  static final double AvatarSpeed = 900; 
  static final int AvatarRadius = 55;
  static final int AvatarWidth = 75;
  static final int AvatarHeight = 110;


  
  static final double BulletSpeed = 200;
  static final int BulletRadius = 3;
  
  static final int TYPE_AVATAR  = 1;
  static final int TYPE_BULLET    = 3;
  static final int TYPE_PLAYBUTTON = 4;
  static final int TYPE_QUITBUTTON = 5;
  static final int TYPE_GAMEOVER = 6;
  static final int TYPE_SCORE = 7;

} 
