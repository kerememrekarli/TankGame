import java.awt.*;
import java.awt.image.*;
import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;

import javax.imageio.ImageIO;
import javax.swing.*;

class B_Panel extends JPanel implements A_GraphicSystem
{
	// constants
	private static final long serialVersionUID = 1L;
	private static final Font font = new Font("Courier",Font.BOLD,40);


	// InputSystem is an external instance
	private B_InputSystem inputSystem = new B_InputSystem();
	private A_World       world       = null;
	private BufferedImage image = null;

	// GraphicsSystem variables
	//
	private GraphicsConfiguration graphicsConf = 
			GraphicsEnvironment.getLocalGraphicsEnvironment().
			getDefaultScreenDevice().getDefaultConfiguration();
	private BufferedImage imageBuffer;
	private Graphics      graphics;



	public B_Panel()
	{ 
		this.setSize(A_Const.WORLD_WIDTH,A_Const.WORLD_HEIGHT);  
		imageBuffer = graphicsConf.createCompatibleImage(
				this.getWidth(), this.getHeight());	 
		graphics = imageBuffer.getGraphics();

		// initialize Listeners
		this.addMouseListener(inputSystem);
		this.addMouseMotionListener(inputSystem);
		this.addKeyListener(inputSystem);

	}

	public void clear()
	{ 
		String path = Paths.get("resource/backgr.jpeg").toAbsolutePath().toString();
		try {
			image = ImageIO.read(new File(path));
			graphics.drawImage(image, 0,0,null);
			if( ((Game_World) world).menu) {
				// menu design here
			 path = Paths.get("resource/name.png").toAbsolutePath().toString();
				image = ImageIO.read(new File(path));
				graphics.drawImage(image, 200,90, null);
			} 
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public final void draw(A_GameObject obj)
	{	  
		if(!((Game_World) world).menu) {
			if( obj.type() == A_Const.TYPE_AVATAR ) {
				String pp; 
				Game_Avatar a = (Game_Avatar) obj;
				switch (a.state) {
				case 0: pp = "0"; break;
				case 1: pp = "1"; break;
				case 2: pp = "2"; break;
				case 3: pp = "3"; break;
				case 4: pp = "4"; break;
				case 5: pp = "5"; break;
				case 6: pp = "6"; break;
				case 7: pp = "7"; break;
				default: pp = "0"; break;
				}
				String cc = (obj.color == Color.red? "red": "blue");
				String path = Paths.get("resource/" + cc + "Avatar"+ pp + ".png").toAbsolutePath().toString();
				try {
					image = ImageIO.read(new File(path));
				} catch (IOException e) {
					e.printStackTrace();
				}
				int xx = (int)(obj.x- obj.radius);
				int yy = (int)(obj.y-obj.radius);
				if( a.state == 0 || a.state == 4) {
					yy += A_Const.AvatarRadius - A_Const.AvatarWidth/2 ;
				} else if( a.state == 2 || a.state == 6) {
					xx += A_Const.AvatarRadius - A_Const.AvatarWidth/2 ;
				} else {
					yy-=5;
					xx-=5;
				}
				graphics.drawImage(image, xx,yy,null);
			}else if( obj.type() == A_Const.TYPE_BULLET ) {
				int x = (int)(obj.x-obj.radius);
				int y = (int)(obj.y-obj.radius);
				int d = (int) (2*obj.radius);
				if( obj.color == Color.blue) {
					graphics.setColor(Color.blue);
				} else {
					graphics.setColor(Color.red);
				}
				graphics.fillOval(x, y, d, d);
			}
		}
	}



	public final void draw(A_TextObject text)
	{	  
		if(!((Game_World) world).menu && !(world.gameOver) &&
				( text.type() == A_Const.TYPE_PLAYBUTTON || text.type() == A_Const.TYPE_QUITBUTTON 
						)) return;
		graphics.setColor(text.color);
		if(text.type() == A_Const.TYPE_SCORE && !((Game_World) world).menu) {
			try {
				String path;
				graphics.setColor(Color.white);
				graphics.setFont(new Font("American Typewriter",Font.BOLD,30));
				path = Paths.get("resource/smallblue.png").toAbsolutePath().toString();
				image = ImageIO.read(new File(path));
				graphics.drawImage(image, 7,5,null);
				path = Integer.toString(((Game_Avatar) world.avatar1).score);

				graphics.drawString(path, 105, 40);
				path = Paths.get("resource/smallred.png").toAbsolutePath().toString();
				image = ImageIO.read(new File(path));
				graphics.drawImage(image, A_Const.WORLD_WIDTH-90,5,null);
				path = Integer.toString(((Game_Avatar) world.avatar2).score);

				graphics.drawString(path, A_Const.WORLD_WIDTH-165, 40);
			}
			catch (IOException e) {
				e.printStackTrace();
			}
		} else if( text.type() == A_Const.TYPE_GAMEOVER && world.gameOver ) {			
			try {
				String path;
				graphics.setColor(Color.white);
				graphics.setFont(new Font("American Typewriter",Font.BOLD,70));

				graphics.drawString(text.toString(), (int)text.x, (int)text.y);
				path = Paths.get("resource/blueAvatar.png").toAbsolutePath().toString();
				image = ImageIO.read(new File(path));
				graphics.drawImage(image, text.x,text.y +40,null);
				path = Integer.toString(((Game_Avatar) world.avatar1).score);

				graphics.drawString(path,text.x+280,text.y +140);
				path = Paths.get("resource/redAvatar.png").toAbsolutePath().toString();
				image = ImageIO.read(new File(path));
				graphics.drawImage(image, text.x,text.y +200,null);
				path = Integer.toString(((Game_Avatar) world.avatar2).score);
				graphics.drawString(path, text.x+281,text.y +290);

			}
			catch (IOException e) {
				e.printStackTrace();
			}
		}else if(( text.type() == A_Const.TYPE_QUITBUTTON || text.type() == A_Const.TYPE_PLAYBUTTON)) {
			graphics.setFont(font);
			graphics.drawString(text.toString(), (int)text.x+1, (int)text.y+1);    
			graphics.drawString(text.toString(), (int)text.x, (int)text.y);
		}
	}


	public void redraw()
	{ this.getGraphics().drawImage(imageBuffer, 0, 0, this);
	}

	public final A_InputSystem getInputSystem() { return inputSystem; }
	public final void setWorld(A_World world_)  {this.world = world_;}
}

