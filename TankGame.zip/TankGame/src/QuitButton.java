import java.awt.Color;

public class QuitButton extends A_TextObject{

	public QuitButton(int x_, int y_) {
		super(x_, y_, Color.white);
	}

	@Override
	public String toString() {
		return "Quit";
	}
	public int type() {
		return A_Const.TYPE_QUITBUTTON; 
	}

}
