public class Game_PhysicsSystem extends A_PhysicsSystem
{

	Game_PhysicsSystem(A_World w)
	{ super(w);
	}


	//
	// collisions :
	//bullet-jet
	//jet-jet
	//
	//TO DO
	public A_GameObjectList getCollisions(A_GameObject object)
	{

		A_GameObjectList result = new A_GameObjectList();

		int len = world.gameObjects.size();
		for(int i=0; i<len; i++)
		{
			A_GameObject obj2 = world.gameObjects.get(i);

			// an object doesn't collide with itself
			if(obj2==object) continue;
			if(obj2.type() == A_Const.TYPE_BULLET) break; 

			// check if they touch each other
			double dist = object.radius+obj2.radius;
			double dx   = object.x-obj2.x;
			double dy   = object.y-obj2.y;

			if(dx*dx+dy*dy +100< dist*dist)
			{ result.add(obj2);
			}
		}

		return result;
	}


}