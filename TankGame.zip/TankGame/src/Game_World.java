import java.awt.Color;

public class Game_World extends A_World 
{
	boolean menu = true; 
	PlayButton pb;
	QuitButton qb;
	GameOver go; 

	@Override
	protected void init() {
		// add the Avatar
		avatar1 = new Game_Avatar(140, 130,0, Color.blue); //avatar1=blue 
		gameObjects.add(avatar1);
		avatar2 = new Game_Avatar(A_Const.WORLD_WIDTH-40-A_Const.AvatarHeight,
				A_Const.WORLD_HEIGHT-50-A_Const.AvatarHeight,4, Color.red);
		gameObjects.add(avatar2);


		// add text objects		
		pb = new PlayButton(320, 550);
		textObjects.add(pb);
		qb = new QuitButton(460, 550);
		textObjects.add(qb);
		go = new GameOver( 280, 100);
		textObjects.add(go);
		Game_Score bluesc = new Game_Score(10,10,Color.blue);
		textObjects.add(bluesc);
		Game_Score greensc = new Game_Score(10,10,Color.red);
		textObjects.add(greensc);

	}

	@Override
	protected void processUserInput(A_UserInput userInput, double diffSeconds) {
		char key = 0;
		if(userInput.isKeyEvent) {
			key = userInput.keyPressed;
		}
		if(menu || gameOver) {
			if(userInput.isMouseEvent) {
				int x = userInput.mouseMovedX; 
				int y = userInput.mouseMovedY;
				// mouse located over play 
				if( x >= pb.x-5 && x <= pb.x+85 && y <= pb.y+5 &&  y >= pb.y-35) {
					if(userInput.isMousePressed) {
						menu = false;
						if(gameOver) {
							gameOver= false;
							((Game_Avatar) avatar1).score = 100;
							((Game_Avatar) avatar2).score = 100;
							avatar1.x = 140; 
							avatar1.y = 130; 
							((Game_Avatar) avatar1).state = 0;
							((Game_Avatar) avatar2).state = 4;						 
							avatar2.x = A_Const.WORLD_WIDTH-40-A_Const.AvatarHeight;						
							avatar2.y = A_Const.WORLD_HEIGHT-50-A_Const.AvatarHeight;
						}
						pb.color = Color.white;
						userInput.mouseButton=0;
					}
				}else {
					pb.color = Color.white;
					// mouse located over quit 
					if( x >= qb.x-5 && x <= qb.x+85 && y <= qb.y+5 &&  y >= qb.y-35) {
						if(userInput.isMousePressed) {
							System.exit(0);
						}
					}else {

					}
				}
			}
		}else {

			if(key=='a'){   //avatar1 is moving to the left  //change states
				((Game_Avatar) avatar1).state--; 
				if(((Game_Avatar) avatar1).state<0) ((Game_Avatar) avatar1).state+=8;
			} else if( key =='d') {   //avatar1 is moving to the right
				((Game_Avatar) avatar1).state++; 
				if(((Game_Avatar) avatar1).state>7) ((Game_Avatar) avatar1).state-=8;
			}
			if(key=='w'){   //avatar1 is moving forward
				avatar1.isMoving = true; 
			}else {    //if w is not pressed, the avatar doesnt move
				avatar1.isMoving = false;
			}
			if(key == 'x') {
				avatarShoots(avatar1);
			}

			if(key=='j'){   //avatar2 is moving to the left  //change states
				((Game_Avatar) avatar2).state--; 
				if(((Game_Avatar) avatar2).state<0) ((Game_Avatar) avatar2).state+=8;
			} else if( key =='l') {   //avatar1 is moving to the right
				((Game_Avatar) avatar2).state++; 
				if(((Game_Avatar) avatar2).state>7) ((Game_Avatar) avatar2).state-=8;
			}
			if(key=='i'){   //avatar2 is moving forward
				avatar2.isMoving = true;
			}else {    //if w is not pressed, the avatar doesnt move
				avatar2.isMoving = false;
			}
			if(key == 'm') {
				avatarShoots(avatar2);
			}
		}

		if(key==(char)27) System.exit(0);
	}


	@Override
	protected void createNewObjects(double diffSeconds) {
		if(!menu && !gameOver) 
		{
		}
	}

	private void avatarShoots(A_GameObject avatar) {
		Game_Bullet b = new Game_Bullet(avatar.x+ (int)(avatar.radius*Math.cos(avatar.alfa)),
				avatar.y + (int)(avatar.radius*Math.sin(avatar.alfa)), avatar.alfa, avatar.color);
		gameObjects.add(b);
	}

}
