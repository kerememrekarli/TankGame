interface A_InputSystem 
{
  // return User Input Object
  A_UserInput getUserInput();
}

