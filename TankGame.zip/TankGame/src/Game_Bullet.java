import java.awt.Color;

public class Game_Bullet extends A_GameObject {

	public Game_Bullet(double x_, double y_, double a_, Color c_) {
		super(x_, y_, a_, A_Const.BulletSpeed, A_Const.BulletRadius, c_);
	}

	@Override
	public void move(double diffSeconds) {
		// move one step
		x += Math.cos(alfa)*speed*diffSeconds;
		y += Math.sin(alfa)*speed*diffSeconds;		   
		if( y <-5 || y > A_Const.WORLD_HEIGHT || x < -5 || x > A_Const.WORLD_WIDTH) isLiving = false;

		A_GameObjectList collide = world.getPhysicsSystem().getCollisions(this);
		for(int i=0; i<collide.size(); i++)
		{ 					
			if( collide.get(i).type() == A_Const.TYPE_AVATAR ) {
				if (this.color== Color.blue && collide.get(i).color == Color.red)  {
					((Game_Avatar) world.avatar2).score-=5;
					this.isLiving = false;
				}else if( this.color== Color.red && collide.get(i).color == Color.blue) {
					((Game_Avatar) world.avatar1).score-=5;
					this.isLiving = false;
				}
			}
		}
		
		if(((Game_Avatar) world.avatar1).score <=0 || ((Game_Avatar) world.avatar2).score <=0) {
			world.gameOver = true;
		}
	}

	@Override
	int type() {
		return A_Const.TYPE_BULLET;
	}

}
